#!bin/bash

xdotool key $1